#include "ofApp.h"


// declaracion de variables
const int N = 256;			//n�mero de bandas en el espectro
float spectrum[N];			//lista de bandas de frecuencia, con N valores
float Rad = 500;			//radio de la nube de puntos
float Vel = 0.1;			//velocidad con la que se mueven los puntos
int bandRad = 2;			//�ndice de la banda que controla el radio
int bandVel = 100;			//�ndice de la banda que controla la velocidad
const int nPoints = 300;	//n�mero de puntos en la nube

float tx[nPoints], ty[nPoints];	// control de cambios suaves por medio de PerlinNoise
ofPoint p[nPoints];			// posiciones de los puntos de la nube

float time0 = 0;			// variable de tiempo, asociada con la velocidad


						
//--------------------------------------------------------------
void ofApp::setup(){
	//inicializa archivo de audio
	sound.loadSound("fuego.mp3");	// cargar el archivo de audio .wav (o .mp3?)
	sound.setLoop( true );					// loopear audio?
	sound.play();							// comienza la reproducci�n

	//inicializa los valores del espectro
	for (int i=0; i<N; i++) {
		spectrum[i] = 0.0;
	}

	//inicializa las posiciones de cada punto
	for ( int j=0; j<nPoints; j++ ) {
		tx[j] = ofRandom( 0, 1000 );	
		ty[j] = ofRandom( 0, 1000 );
	}
}

//--------------------------------------------------------------
void ofApp::update(){	

	// actualizar AUDIO

	//actualiza el reproductor de audio
	ofSoundUpdate();	
	//calcula el valor de las componentes del espectro
	float *val = ofSoundGetSpectrum( N );

	// actualiza cada banda del espectro
	// si el nuevo valor es mayor, actualizalo
	// si no es mayor, reduce suavemente su valor
	for ( int i=0; i<N; i++ ) {
		spectrum[i] *= 0.97;	//caida suave de los valores de cada banda
		spectrum[i] = max( spectrum[i], val[i] );
	}

	// actualizar SISTEMA DE PARTICULAS

	//calcular cuanto tiempo ha pasado desde la ultima actualizaci�n del frame 	
	float time = ofGetElapsedTimef();
	float dt = time - time0;
	dt = ofClamp( dt, 0.0, 0.1 ); // acota el valor a un rango determinado
	time0 = time;	//fijamos el ultimo momento en que hubo actualizaci�n

	//actualiza el radio y velocidad con los valores de las bandas correspondientes
	//la funcion ofMap traslada una variable de un rango a otro
	Rad = ofMap( spectrum[ bandRad ], 1, 3, 300, 1000, true );
	Vel = ofMap( spectrum[ bandVel ], 0, 0.1, 0.05, 2.5 );
	
	//actualiza las posiciones de las particulas
	for (int j=0; j<nPoints; j++) {
		// calcula unos offsets asociados con la posici�n
		tx[j] += Vel * dt;   // tx[j] = tx[j] + Vel * dt;
		ty[j] += Vel * dt;
		// calculas las nuevas posiciones a partir de los offsets
		p[j].x = ofSignedNoise( tx[j] ) * Rad;
		p[j].y = ofSignedNoise( ty[j] ) * Rad;
	}
}

//--------------------------------------------------------------
void ofApp::draw(){
	//ofBackgroundGradient(ofColor::blueSteel, ofColor::darkSlateGray);
	if (spectrum[2] > 0.3) {
		ofBackgroundGradient(ofColor::blueSteel, ofColor(ofRandom(255), ofRandom(255), ofRandom(255)));
	}
	//rect�ngulo del espectro
	ofSetColor( 230, 230, 230 );
	ofFill();
	ofRect( 10, 700, N * 6, -100 );

	//dibuja el espectro
	ofSetColor( 0, 0, 0 );
	for (int i=0; i<N; i++) {
		//Draw bandRad and bandVel by black color,
		//and other by gray color
		if ( i == bandRad || i == bandVel ) {
			// el operador || significa 'OR'
			ofSetColor( 0, 0, 0 ); //Black color
		}
		else {
			ofSetColor( 128, 128, 128 ); //Gray color
		}
		ofRect( 10 + i * 5, 700, 3, -spectrum[i] * 500 );
	}

	//Dibujar nube de puntos
	//cambiar el origen al centro del lienzo 
	ofPushMatrix();
	ofTranslate( ofGetWidth() / 2, ofGetHeight() / 2 );

	//Poner los puntos
	ofSetColor( 0, 0, 0 );
	ofFill();
	
	// el tama�o de las particulas est� conectado 
	// a distintas bandas de frecuencia
	for (int i=0; i<nPoints; i++) {
		float tam;
		if (i > 10 && i < 60) {
			tam = spectrum[i] * 50;
		}
		ofSetColor(255, ofMap(spectrum[10], 0, 1, 0, 255), 0);
		ofCircle( p[i], spectrum[i % 255] * 50); 
		// el operador de m�dulo (%) devuelve el resuduo entero de la division
	}

	//dibuja las lineas que unen los puntos
	float dist = 40;	//umbral de distancia
	for (int j=0; j<nPoints; j++) {
		for (int k=j+1; k<nPoints; k++) {
			// si la distancia entre el punto[j] y el punto [k] es menor que dist 
			if ( ofDist( p[j].x, p[j].y, p[k].x, p[k].y )
				< dist ) {
					ofSetColor(0, k, j);
					ofLine( p[j], p[k] );
			}
			else {
				ofNoFill();
				ofSetColor(j%255, 255, 0, k%5);
				ofRect(p[j], p[k].x, p[k].y);
			}
		}
	}

	//restaura el origen
	ofPopMatrix();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
